import { ClearanceCaseManager } from "@/components/clearance-case-manager"

export default function Home() {
  return <ClearanceCaseManager />
}
