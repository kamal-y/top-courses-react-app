"use client"

import { useState } from "react"
import { Menu, Home, ChevronDown, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function ClearanceCaseManager() {
  const [activeTab, setActiveTab] = useState("Documents")

  const tabs = ["Documents", "Eligibility", "Rx/ Active Payers", "Copy Setup", "Billing Setup"]

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-[#1a3a3a] text-white flex items-center justify-between px-4 py-2">
        <div className="flex items-center gap-4">
          <Menu className="h-5 w-5 cursor-pointer" />
          <div className="flex items-center gap-1">
            <span className="font-semibold text-lg">Accredo</span>
            <span className="text-sm text-gray-300">By EverNorth</span>
          </div>
          <span className="text-white ml-4">Clearance Case Manager</span>
          <Button className="bg-[#0d7377] hover:bg-[#0a5c5f] text-white ml-4 h-8 px-3 text-sm">+ Get Next</Button>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm">Work Area</span>
          <span className="bg-[#0d7377] text-white px-3 py-1 rounded text-sm font-medium">EE - 91035</span>
          <span className="text-sm">Kamal Yadav</span>
          <div className="w-8 h-8 rounded-full bg-[#c4a574] flex items-center justify-center">
            <User className="h-5 w-5 text-white" />
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Main Content */}
        <div className="flex-1 p-4">
          {/* Patient Header Card */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center">
                  <User className="h-8 w-8 text-gray-400" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-gray-900">Richer, Anthony</h1>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[#0d7377] text-sm font-medium">AGE 50</span>
                    <span className="text-gray-500 text-sm">(07/19/1973)</span>
                    <span className="text-gray-500 text-sm">Male</span>
                  </div>
                </div>
                <div className="ml-6 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Home className="h-4 w-4" />
                    <span>7290 Test Dr</span>
                  </div>
                  <span>Portland Or 97233</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button className="bg-[#0d7377] hover:bg-[#0a5c5f] text-white h-9 px-4">Patient 360</Button>
                <Button variant="outline" className="h-9 px-4 border-gray-300 bg-transparent">
                  <svg className="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                    />
                  </svg>
                  Patient
                </Button>
                <Button variant="outline" className="h-9 px-4 border-gray-300 bg-transparent">
                  CSP
                </Button>
              </div>
            </div>

            {/* Patient Details Grid */}
            <div className="grid grid-cols-4 gap-x-8 gap-y-4 mt-6 text-sm">
              <div>
                <span className="text-gray-500">Patient ID:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Preferred Language:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Phone Number:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Need By Date:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Ship Date:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Therapy Name:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Physician:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Concierge Physician:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Special Instructions:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
              <div>
                <span className="text-gray-500">Single Patient Profile:</span>
                <p className="font-medium text-gray-900">15136098</p>
              </div>
            </div>
          </div>

          {/* Patient Tabs Section */}
          <div className="bg-white rounded-lg shadow-sm">
            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Patient</h2>
              <div className="flex">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 text-sm rounded-md ${
                      activeTab === tab ? "bg-[#1a3a3a] text-white" : "text-gray-600 hover:bg-gray-100"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4">
              {/* Overview Section */}
              <div className="mb-4">
                <h3 className="font-semibold text-gray-900">Overview - 1</h3>
                <p className="text-sm text-gray-500 mt-1">This is the overview content for document</p>
              </div>

              {/* Payer Section */}
              <div className="border-t pt-4">
                <div className="flex items-center gap-4 mb-4">
                  <span className="font-medium text-gray-900">Payer</span>
                  <span className="text-sm text-gray-500">Place of Service ID</span>
                  <Input placeholder="Enter place of service #" className="w-48 h-9" />
                </div>

                {/* Form Fields */}
                <div className="flex items-end gap-4 flex-wrap mb-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-sm text-gray-600">Billing Sequence *</label>
                    <Select>
                      <SelectTrigger className="w-28 h-9">
                        <SelectValue placeholder="select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-sm text-gray-600">Benefit Type *</label>
                    <Select>
                      <SelectTrigger className="w-28 h-9">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="medical">Medical</SelectItem>
                        <SelectItem value="pharmacy">Pharmacy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-sm text-gray-600">BIN</label>
                    <Input placeholder="Enter BIN" className="w-28 h-9" />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-sm text-gray-600">PCN</label>
                    <Input placeholder="Min 2 char" className="w-28 h-9" />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-sm text-gray-600">Group Number</label>
                    <Input placeholder="Mail order group" className="w-36 h-9" />
                  </div>

                  <div className="flex items-center gap-2 pb-1">
                    <Checkbox id="mailNpi" />
                    <label htmlFor="mailNpi" className="text-sm text-gray-600">
                      Mail NPI
                    </label>
                  </div>

                  <Button variant="outline" className="h-9 px-6 bg-transparent">
                    Clear
                  </Button>
                  <Button className="bg-[#0d7377] hover:bg-[#0a5c5f] text-white h-9 px-6">Search</Button>
                </div>

                {/* Table */}
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-[#1a3a3a] text-white">
                      <tr>
                        <th className="px-4 py-3 text-left text-sm font-medium">Product ID</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">Product Name</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">Billing Sequence</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">Benefit Type</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="px-4 py-3 text-sm text-gray-500 text-center">-</td>
                        <td className="px-4 py-3 text-sm text-gray-500 text-center">-</td>
                        <td className="px-4 py-3 text-sm text-gray-500 text-center">-</td>
                        <td className="px-4 py-3 text-sm text-gray-500 text-center">-</td>
                        <td className="px-4 py-3 text-sm text-gray-500 text-center">-</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="w-80 bg-white border-l border-gray-200 p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Insurance Entry</h2>

          {/* New Referral Card */}
          <div className="border border-gray-200 rounded-lg p-3 mb-4">
            <div className="flex justify-between items-start mb-1">
              <span className="text-sm font-medium text-gray-900">New Referral</span>
              <span className="text-sm text-gray-500">(EE-91035)</span>
            </div>
            <p className="text-sm text-orange-500 font-medium">New Eligibility Not Found</p>
            <p className="text-xs text-gray-500 mt-1">Created Date: 08/10/2025, 08:20 PM</p>
          </div>

          {/* Rx Summary Dropdown */}
          <div className="border border-gray-200 rounded-lg p-3 mb-4">
            <div className="flex justify-between items-center cursor-pointer">
              <span className="text-sm font-medium text-gray-900">Rx Summary</span>
              <ChevronDown className="h-4 w-4 text-gray-500" />
            </div>
          </div>

          {/* Payer List */}
          <div className="border border-gray-200 rounded-lg p-3 mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-900">Payer List</span>
            </div>
            <p className="text-sm text-gray-500">No Payer List Available</p>
          </div>

          {/* Rx Summary Dropdown 2 */}
          <div className="border border-gray-200 rounded-lg p-3 mb-4">
            <div className="flex justify-between items-center cursor-pointer">
              <span className="text-sm font-medium text-gray-900">Rx Summary</span>
              <ChevronDown className="h-4 w-4 text-gray-500" />
            </div>
          </div>

          {/* Policy Information */}
          <div className="border border-gray-200 rounded-lg p-3 mb-4">
            <div className="flex justify-between items-center mb-4 cursor-pointer">
              <span className="text-sm font-semibold text-gray-900">Policy Information</span>
              <ChevronDown className="h-4 w-4 text-gray-500" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Cardholder ID *</label>
                <Select>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="id1">ID 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Person Code *</label>
                <Select>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="code1">Code 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Effective Date *</label>
                <Select>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date1">Date 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Therapy Type *</label>
                <Select>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="type1">Type 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Service *</label>
                <Select>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="service1">Service 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Expiration Date *</label>
                <Select>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="exp1">Exp 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Policyholder Information */}
          <div className="border border-gray-200 rounded-lg p-3 mb-4">
            <div className="flex justify-between items-center mb-4 cursor-pointer">
              <span className="text-sm font-semibold text-gray-900">Policyholder Information</span>
              <ChevronDown className="h-4 w-4 text-gray-500" />
            </div>

            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Relationship *</label>
                <Select>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="self">Self</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">DOB *</label>
                <Select>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dob1">DOB 1</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="mb-3">
              <label className="text-xs text-gray-600 mb-1 block">First Name</label>
              <Input placeholder="Select" className="h-8 text-sm" />
            </div>

            <div>
              <label className="text-xs text-gray-600 mb-1 block">Last Name</label>
              <Input placeholder="Select" className="h-8 text-sm" />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-between mt-4">
            <Button variant="outline" className="h-9 px-6 bg-transparent">
              Clear
            </Button>
            <Button className="bg-[#0d7377] hover:bg-[#0a5c5f] text-white h-9 px-6">Save</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
